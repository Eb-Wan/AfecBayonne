const log = () => console.log("Bienvenue sur mon seveur (épique)");
log();
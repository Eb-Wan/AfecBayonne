dans la racine :
    npm init -y
    npm i
    npm start
    
dans frontend :
    npm init -y
    npm i
    npm start